import { useEffect, useState, useRef } from 'react'
import { db, storage, auth } from '../Firebase'
import { collection, addDoc, Timestamp } from 'firebase/firestore'
import { getDownloadURL, ref, uploadBytesResumable } from 'firebase/storage'
import { createUserWithEmailAndPassword, signInWithEmailAndPassword } from 'firebase/auth';
import { useNavigate } from 'react-router-dom';



export default function Register() {
    const [file, setFile] = useState(null)
    const [percent, setPercent] = useState(false)
    const [imageUrl, setImageUrl] = useState(null)
    const [fileName, setFileName] = useState(null)

    const [name, setname] = useState('')
    const [password, setpassword] = useState('')
    
    const [mobilenumber, setmobilenumber] = useState('')
    const [email, setemail] = useState('')
  
    const [address, setaddress] = useState('')
 
    const [image, setimage] = useState('')
  


    const navigate = useNavigate()
    const inputRef = useRef(null);

    const handleImageClick = () => {
        inputRef.current.click();

    }
    const handleImageChange = (event) => {
        const file = event.target.files[0];
        console.log(file);
        setimage(event.target.files[0]);

    }

    const handleform = async (e) => {
        uploadFile()
        e.preventDefault()

        console.log(name)


    }
    const uploadFile = () => {
        if (!file) {
            alert("Please upload an image first!");
        }
        // console.log("File", file)
        // console.log("File Name", file.name)

        const fileName = `${Date.now()}-${file.name}`
        const storageRef = ref(storage, `/files/${fileName}`);

        // progress can be paused and resumed. It also exposes progress updates.
        // Receives the storage reference and the file to upload.
        const uploadTask = uploadBytesResumable(storageRef, file);

        uploadTask.on(
            "state_changed",
            (snapshot) => {
                const percent = Math.round(
                    (snapshot.bytesTransferred / snapshot.totalBytes) * 100
                );
                // update progress
                setPercent(percent);
            },
            (err) => console.log(err),
            () => {
                // download url
                getDownloadURL(uploadTask.snapshot.ref).then((url) => {
                    console.log("URL", url);
                    setFileName(fileName)
                    setImageUrl(url)
                });
            }
        );
    };

    const saveData = async () => {
        try {

            await createUserWithEmailAndPassword(auth, email, password)
                .then((userCredential) => {
                    // Signed in
                    const user = userCredential.user;
                    console.log(user);
                    let data = {
                        mobilenumber: mobilenumber,
                        email: email,
                        password: password,
                      
                        image: imageUrl,
                        uid: user.uid,
                       
                        created: Timestamp.now(),
                        
                    }
                    adddata(data)

                    // ...
                })
                .catch((error) => {
                    const errorCode = error.code;
                    const errorMessage = error.message;
                    console.log(errorCode, errorMessage);
                    alert("Error: " + errorMessage)
                    // ..
                });

            //   


        } catch (err) {
            alert(err)
        }

    }

    const adddata = async (data) => {
        console.log(data)
        await addDoc(collection(db, 'new-otherusers'), {
           
            Mobilenumber: data?.mobilenumber,
            Email: data?.email,
           
            Address: data?.address,
           
            Image: data?.image,
           
            uid: data?.uid,
           
            created: Timestamp.now()
        })
       
        setemail("")
        setpassword("")
        setmobilenumber("")
      
        setaddress("")
        
        setFile("")
        
        navigate("/login")
        alert("User Created")
    }
    useEffect(() => {
        if (!!imageUrl)
            saveData()
    }, [imageUrl])


    return (
        <>

            <div className="container row px-5 mt-4 prof">
                <div className='row'>
                  <div className='col-md-3'></div>
                    <div className='col-md-6'>
                   

                    <div className="section-title bg-white text-start text-primary pe-3 my-4">
                            <h3>Register Yourself</h3>
                        </div>
                        
                        <div style={{width:'20px'}} onClick={handleImageClick}>
                                    {image ? (
                                     <img src={URL.createObjectURL(image)} alt="" style={{width:'200px'}}/>
                                    ):(
                                        <img className="img-account-profile rounded-circle mb-2  " style={{ "marginBottom": "10px",width:'150px' }} src="http://bootdey.com/img/Content/avatar/avatar1.png" alt="" />

                                    )}
                                   
                                    <input type="file" ref={inputRef}  style={{display:'none'}} onChange={handleImageChange}
                                     onInput={(e) =>
                                       
                                        setFile(e.target.files[0])

                                    }
                                     />
                                    {/* <form className="text-left" onSubmit={handleform}> */}
                                    </div>
                       
                        <form className="text-left" onSubmit={handleform}>
                              <div className='row'>
                              <div class="position-relative w-60 my-2 col-md-6">
                                <input class="form-control bg-transparent w-60 py-3 ps-4 pe-5" type="text" placeholder="Your email" value={email} onChange={(e) => setemail(e.target.value)} />
                            </div>
                            <div class="position-relative w-60 my-2 col-md-6">
                                <input class="form-control bg-transparent w-60 py-3 ps-4 pe-5" type="text" placeholder="Your password" value={password}
                                    onChange={(e) => setpassword(e.target.value)} />
                            </div>
                              </div>
                            
                            <div class="position-relative w-60 my-2">
                                <input class="form-control bg-transparent w-60 py-3 ps-4 pe-5" type="text" placeholder="Mobile number" value={mobilenumber}
                                    onChange={(e) => setmobilenumber(e.target.value)} />
                            </div>
                            <div class="position-relative w-60 my-2">
                                <input class="form-control bg-transparent w-60 py-3 ps-4 pe-5" type="text" placeholder="Your address" value={address}
                                    onChange={(e) => setaddress(e.target.value)} />
                            </div>
                            <button type="submit" class="btn btn-secondary rounded-pill py-3 px-5 my-4 animated slideInRight">Register</button>




                        </form>
                    </div>
                    <div className='col-md-3'></div>

                </div>







            </div>

        </>
    )
}