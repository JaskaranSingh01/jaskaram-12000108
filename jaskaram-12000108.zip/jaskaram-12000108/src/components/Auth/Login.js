import { useNavigate,useParams } from "react-router-dom"
import { useState, CSSProperties } from "react";
import { createUserWithEmailAndPassword, signInWithEmailAndPassword } from 'firebase/auth';
import { auth ,db} from "../Firebase";
import { collection, addDoc, Timestamp } from 'firebase/firestore'


export default function Login() {

	const [email, setemail] = useState('')
    const [password, setpassword] = useState('')
    const [isLogin, setIsLogin] = useState(false)
    const navigate = useNavigate();
    const param = useParams()
    const [id, setId] = useState(param.id)
    console.log(id)


	const handleform = async (e) => {
        e.preventDefault()
        
            await signInWithEmailAndPassword(auth, email, password)
                .then((userCredential) => {
                    // Signed in
                    const user = userCredential.user;
					console.log(user);
					let userdata = {
						email: email,
						uid : user.uid,
						usertype:'customer'
					}
					saveuser(userdata)
                   
                })
                .catch((error) => {
                    const errorCode = error.code;
                    const errorMessage = error.message;
                    console.log(errorCode, errorMessage)
                });
			}
	const saveuser = async (data) =>{
		console.log(data)
		try {
			await addDoc(collection(db, 'users'), {
			  email: data.email,
			  uid: data.uid,
			  usertype: data.usertype,
			})
  
			alert("Login Successful")
			navigate("/home")
		  } catch (err) {
			alert(err)
		  }
	}

	return (
		<>
			
			<div className="login elite-app">
				<div className="container">
               
					<div className="row" style={{ "justifyContent": "center" }}>
						<div className="col-md-2" ></div>
						<div className="col-md-5 login-form-w3-agile">
							<div className="section-title bg-white text-start text-primary pe-3 mb-4 ">
								<h3>Login Now</h3>
							</div>
							<form action="#" method="post" onSubmit={handleform}>
							<div class="position-relative w-60 my-2">
                                <input class="form-control bg-transparent w-60 py-3 ps-4 pe-5" type="text" placeholder="Your email" value={email} onChange={(e) => setemail(e.target.value)} />
                            </div>
							<div class="position-relative w-60 my-2">
                                <input class="form-control bg-transparent w-60 py-3 ps-4 pe-5" type="text" placeholder="Your password" value={password}
										onChange={(e) => setpassword(e.target.value)} />
                            </div>
								
								
								<button type="submit" class="btn btn-secondary rounded-pill py-3 px-5 my-4 animated slideInRight">SignUp</button>
							</form>
							<div className="social_icons agileinfo_social_asd">
								
								<h5>Don't have an account?<i className="fa fa-hand-o-down" aria-hidden="true"></i></h5>
								<div className="sim-button button12">
									<a className="btn btn-secondary rounded-pill py-3 px-4 my-4 animated slideInRight" href="/register">Register Here</a></div>
							</div>

						</div>
						<div className="col-md-3" > </div>

					
					</div>
				</div>
			</div>
		</>
	)
}