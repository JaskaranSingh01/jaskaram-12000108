import { useEffect, useRef, useState } from 'react'
import { db, storage } from './Firebase'
import { collection, addDoc, Timestamp,query, onSnapshot,deleteDoc,doc } from 'firebase/firestore'
import { getDownloadURL, ref, uploadBytesResumable } from 'firebase/storage'
import { Link } from 'react-router-dom'
import { createUserWithEmailAndPassword, getAuth, onAuthStateChanged, signInWithEmailAndPassword } from 'firebase/auth';

export default function Selling(){
    const [idea, setidea] = useState('')
    const[idw,setidw]=useState('')
    const[breed,setBreed]=useState('')
    const[age,setage]=useState('')
    const[milk,setmilk]=useState('')
    const[category,setcategory]=useState('')
    const[price,setprice]=useState('')
    const [file, setFile] = useState(null)
    const [percent, setPercent] = useState(false)
    const [imageUrl, setImageUrl] = useState(null)
    const [fileName, setFileName] = useState(null)
    const [image, setimage] = useState('')
    const inputRef=useRef(null);

    const handleImageClick=()=>{
  inputRef.current.click();

    }
    const handleImageChange=(event)=>{
const file=event.target.files[0];
console.log(file);
setimage(event.target.files[0]);
        
    }


    const handleform = async (e) => {
        uploadFile()
        e.preventDefault()

}
   
    const uploadFile = () => {
        if (!file) {
            alert("Please upload an image first!");
        }
        const fileName = `${Date.now()}-${file.name}`
        const storageRef = ref(storage, `/files/${fileName}`);

        // progress can be paused and resumed. It also exposes progress updates.
        // Receives the storage reference and the file to upload.
        const uploadTask = uploadBytesResumable(storageRef, file);

        uploadTask.on(
            "state_changed",
            (snapshot) => {
                const percent = Math.round(
                    (snapshot.bytesTransferred / snapshot.totalBytes) * 100
                );
                // update progress
                setPercent(percent);
            },
            (err) => console.log(err),
            () => {
                // download url
                getDownloadURL(uploadTask.snapshot.ref).then((url) => {
                    // console.log(url);
                    setFileName(fileName)
                    setImageUrl(url)
                });
            }
        );
    };
 const saveData = async () => {
        try {
            await addDoc(collection(db, 'new-selling'), {
                breed: breed,
                age: age,
                price: price,
                category: category,
                milk:milk,
                image: imageUrl,
                id:idw,
                created: Timestamp.now()
            })
            alert("Submitted")
        } catch (err) {
            alert(err)
        }
    }

    useEffect(() => {
        if (!!imageUrl)
            saveData()
    }, [imageUrl])
    useEffect(()=>{
        const auth = getAuth();
        onAuthStateChanged(auth, (user) => {
            if (user) {
                // User is signed in, see docs for a list of available properties
                // https://firebase.google.com/docs/reference/js/auth.user
                setidw(user.uid)
                console.log(idw)
    
                // ...
            } else {
                // User is signed out
                // ...
            }
        });
    },[]);

    return(
        <>
          <div class="text-center mx-auto wow fadeInUp" data-wow-delay="0.1s" style={{'max-width': '500px'}}>
                        <p class="section-title bg-white text-center text-primary px-3">Selling form</p>
                        <h1 class="mb-5">Fill the required Fields</h1>
                    </div>

                    <div className='container'>
                        <div className='row'>
                            <div className='col-md-3'></div>
                            <div className='col-md-6'>
                            <form action="#" method="post" onSubmit={handleform}>
            <div onClick={handleImageClick}>
                                    {image ? (
                                     <img src={URL.createObjectURL(image)} alt="" style={{width:'200px'}}/>
                                    ):(
                                        <img className="img-account-profile rounded-circle mb-2 " style={{ "marginBottom": "10px",width:"20vh",marginLeft:"40%" }} src="http://bootdey.com/img/Content/avatar/avatar1.png" alt="" />

                                    )}
                                   
                                    <input type="file" ref={inputRef}  style={{display:'none'}} onChange={handleImageChange}
                                     onInput={(e) =>
                                       
                                        setFile(e.target.files[0])

                                    }
                                     />
                                    {/* <form className="text-left" onSubmit={handleform}> */}
                                    </div>
							
							<div class="position-relative w-60 my-2">
                                <input class="form-control bg-transparent w-60 py-3 ps-4 pe-5" type="text" placeholder="Breed:" value={breed}
										onChange={(e) => setBreed(e.target.value)} />
                            </div>
                            <div class="position-relative w-60 my-2">
                                <input class="form-control bg-transparent w-60 py-3 ps-4 pe-5" type="text" placeholder="Age:" value={age}
										onChange={(e) => setage(e.target.value)} />
                            </div>
                            <div class="position-relative w-60 my-2">
                                <input class="form-control bg-transparent w-60 py-3 ps-4 pe-5" type="text" placeholder="Price:" value={price}
										onChange={(e) => setprice(e.target.value)} />
                            </div>
                            
                            <div class="position-relative w-60 my-2">
                                <input class="form-control bg-transparent w-60 py-3 ps-4 pe-5" type="text" placeholder="Milk production" value={milk}
										onChange={(e) => setmilk(e.target.value)} />
                            </div>
                            <div className="position-relative w-60 my-2">

                                        <select className="form-select form-control" placeholder="Category" onChange={(e) => { setcategory(e.target.value) }} >
                                            <option   disabled>course</option>

                                            <option >Cow</option>
                                            <option >Buffalo</option>
                                            <option>Goat</option>
                                        </select >
                                    </div>
								
								
								<button type="submit" class="btn btn-secondary rounded-pill py-3 px-5 my-4 animated slideInRight " style={{marginLeft:"38%"}}>Submit</button>
							</form>
                            </div>
                            <div className='col-md-3'></div>
                        </div>
                    </div>
        	

        

        </>
    )
}