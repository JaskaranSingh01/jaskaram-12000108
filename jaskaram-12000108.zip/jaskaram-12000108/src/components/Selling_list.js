import { useState, useEffect } from 'react'
import { collection, query, orderBy, onSnapshot, deleteDoc, doc } from "firebase/firestore"
import { createUserWithEmailAndPassword, getAuth, onAuthStateChanged, signInWithEmailAndPassword } from 'firebase/auth';

import { db } from './Firebase'
export default function Selling_list() {


    const [tasks, setTasks] = useState([])
    const [idw, setidw] = useState('')

    const handleDelete = async (id) => {
        // alert(id)
        const taskDocRef = doc(db, 'new-selling', id)
        try {
            await deleteDoc(taskDocRef)
        } catch (err) {
            alert(err)
        }
    }
    useEffect(() => {
        const q = query(collection(db, 'new-selling'), orderBy('created', 'desc'))
        onSnapshot(q, (querySnapshot) => {
            setTasks(querySnapshot.docs.map(doc => ({
                id: doc.id,
                data: doc.data()
            })))
        })
        const auth = getAuth();
        onAuthStateChanged(auth, (user) => {
            if (user) {
                // User is signed in, see docs for a list of available properties
                // https://firebase.google.com/docs/reference/js/auth.user
                setidw(user.uid)
                console.log(idw)

                // ...
            } else {
                // User is signed out
                // ...
            }
        });
    }, [])

    return (
        <> <div class="container-xxl py-5">
           <div class="container">
            <div class="text-center mx-auto wow fadeInUp" data-wow-delay="0.1s" style={{'max-width': '500px'}}>
                <p class="section-title bg-white text-center text-primary px-3">Selling list</p>
            </div>
            <div class="row gx-4">
            {tasks.map((task) => (
                task.data.id == idw ? (
                    <div class="col-md-6 col-lg-4 col-xl-3 wow fadeInUp" data-wow-delay="0.1s">
                        <div class="product-item">
                            <div class="position-relative">
                                <img class="img-fluid" style={{width:"100%",height:"200px"}} src={task.data.image} alt="" />
                                <div class="product-overlay">
                                    <a class="btn btn-square btn-secondary rounded-circle m-1" href=""  onClick={() => {
                                            const confirmBox = window.confirm(
                                            "Do you really want to delete this?"
                                            )
                                            if (confirmBox === true) {
                                                // alert(confirmBox)
                                            handleDelete(task.id)
                                            }
                                        }}><i class="bi bi-cart"></i></a>
                                </div>
                            </div>
                            <div class="text-center p-4">
                            <h5 class="mb-3">Breed: {task.data.breed}</h5>
                                    <h5 class="mb-3">Milk production: {task.data.milk}</h5>
                                    <h5 class="mb-3">Age: {task.data.milk}</h5>
                                    <h5 class="mb-3">Animal: {task.data.category}</h5>
                                    <span class="text-primary me-1">{task.data.offer}</span>
                                    <span class="text-decoration-line-through">{task.data.realprice}</span>
                                
                            </div>
                        </div>
                    </div>
                        
                ) : (console.log("no user"))

            ))}

             </div>
             </div>

             </div>



        </>
    )
}