import './App.css';
import Home from './components/Home';
import About from './components/About';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Master from './components/Master';
import Login from './components/Auth/Login';
import Register from './components/Auth/Register';
import Selling from './components/Selling';
import Selling_list from './components/Selling_list';
import Buying from './components/Buying';

function App() {
  return (
   <>
   {/* <Header />

   <Home/>   
   <Footer /> */}
   <BrowserRouter>
   <Routes>
   <Route path='/' element={<Master />}>
   <Route path='/home' element={<Home />}></Route>
   <Route path='/about' element={<About />}></Route>
   <Route path='/login' element={<Login isFromLogin={true}/>}></Route>
   <Route path='/register' element={<Register isFromLogin={false}/>}></Route>
   <Route path='/selling' element={<Selling/>}></Route>
   <Route path='/sellinglist' element={<Selling_list/>}></Route>
   <Route path='/buying' element={<Buying/>}></Route>






    </Route>


   </Routes>
   </BrowserRouter>

   </>
   
   
 );
}

export default App;
